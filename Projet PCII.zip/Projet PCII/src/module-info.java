module main {
	requires java.desktop;
}