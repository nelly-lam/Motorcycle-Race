package Vue;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import Modele.Moto;
import Modele.Route;

public class AffichageScore extends JPanel implements Observer{

	/*************CONSTANTES*************/
	private static final long serialVersionUID = 1L;
	
	/*************ATTRIBUTS*************/
    JLabel kilometre = new JLabel();
    JLabel nbKilometre = new JLabel();
    JLabel score = new JLabel();
    JLabel nbScore = new JLabel();
    
	private final Moto moto;
	private final Route route;
	
	/*************CONSTRUCTEUR*************/
	public AffichageScore(Moto m, Route r) {
		this.moto = m;
		this.route = r;
		this.route.addObserver(this);
		
		this.setSize(new Dimension(50,AffichageJeu.LARGAFFICHAGE));
		
		JPanel panel = new JPanel(new FlowLayout());
		
		this.kilometre.setText("Nombre de kilometres parcourus : ");
		this.nbKilometre.setText(String.valueOf(this.route.getKilometre()));
		
		this.score.setText("Score : ");
		this.nbScore.setText(String.valueOf(this.route.getKilometre()));
		
		panel.add(kilometre);
		panel.add(nbKilometre);
		panel.add(score);
		panel.add(nbScore);
	}

	/*************METHODES*************/
	public Moto getMoto() { return moto; }
	public Route getRoute() {return route; }

	@Override
	public void update() {
		this.nbKilometre.setText(String.valueOf(this.getRoute().getKilometre()));
		this.nbScore.setText(String.valueOf(this.getRoute().getKilometre()));
	}
	
	

}
