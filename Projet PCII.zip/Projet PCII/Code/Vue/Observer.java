package Vue;

public interface Observer {
    void update();
}
