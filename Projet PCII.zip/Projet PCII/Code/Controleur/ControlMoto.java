package Controleur;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Modele.Moto;

public class ControlMoto implements KeyListener{
	
	/****************ATTRIBUTS****************/
	private final Moto moto;
	
	public ControlMoto(Moto m) {
		this.moto = m;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyPressed(KeyEvent e) {
		System.out.printf("on rentre dans keyPressed\n");
		switch (e.getKeyCode()){
		   case (KeyEvent.VK_RIGHT): // quand la touche correspond � celui de la fleche droite du clavier
			   System.out.printf("La moto se deplace a droite\n");
			   this.getMoto().deplaceDroit();
		   break;
		   case (KeyEvent.VK_LEFT): 
			   this.getMoto().deplaceGauche();
		   break;
		  }
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	public Moto getMoto() { return moto; }

}
